import type { Address } from "viem";

// Tokens
export const USDY_ADDRESS =
  "0x54cD901491AeF397084453F4372B93c33260e2A6" as const;
  
export const USDC_ADDRESS =
  "0xe15fC38F6D8c56aF07bbCBe3BAf5708A2Bf42392" as Address;