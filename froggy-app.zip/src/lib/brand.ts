﻿// src/lib/brand.ts
export const brand = {
    bg: "#0b1221",
    primary: "#6eb819",
    secondary: "#5AA6FF",
    text: "#E9F1FF",
    card: "#121a2e",
    subtle: "#93A8C3",
} as const;
